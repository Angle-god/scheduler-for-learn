#ifndef __SCHED_H__
#define __SCHED_H__

#include <stdint.h>

#define sched_LIST_NUM 16


typedef void (*sched_func)(void *arg);

struct sched_item_info {
    uint32_t period;
    uint32_t last_tick;
    sched_func cb;
    void *arg;
};

typedef uint32_t (*get_tick) (void);

struct sched_info {
    struct sched_item_info sched_list[sched_LIST_NUM];
    uint16_t used;
    volatile uint32_t jiffies;
    uint32_t last_tick;
    uint32_t current_tick;
};


typedef void (*sched_func)(void *arg);
extern void sched_register_ms(sched_func fn, void *arg, uint32_t period_ms);
extern void sched_init(void);
extern void sched_run_ms(void);
extern uint32_t get_jiffies(void);
extern void sched_update(void);

#endif

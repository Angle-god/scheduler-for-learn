#include "sched.h"

static struct sched_info sched_entry;

uint32_t get_jiffies(void)
{
    return sched_entry.jiffies;
}

void sched_register_ms(sched_func fn, void *arg, uint32_t period_ms)
{
    if (sched_entry.used >= sched_LIST_NUM) {
        return;
    }
    sched_entry.sched_list[sched_entry.used].period    = period_ms;
    sched_entry.sched_list[sched_entry.used].cb        = fn;
    sched_entry.sched_list[sched_entry.used].last_tick = sched_entry.jiffies;
    sched_entry.sched_list[sched_entry.used++].arg     = arg;
}

void sched_init(void)
{
    sched_entry.jiffies = 0;
    sched_entry.used = 0;
    sched_entry.last_tick = 0;
    sched_entry.current_tick = 0;
}

void sched_update(void)
{
	sched_entry.jiffies++;
}

void sched_run_ms(void)
{
    int i = 0;
    struct sched_info *sched_ptr = &sched_entry;

    for (; i < sched_ptr->used; i++) {
        if (sched_ptr->jiffies >= (0xffffffff&(sched_ptr->sched_list[i].last_tick + sched_ptr->sched_list[i].period))) {
            sched_ptr->sched_list[i].last_tick = sched_ptr->jiffies;
            sched_ptr->sched_list[i].cb(sched_ptr->sched_list[i].arg);
        }
    }
}
